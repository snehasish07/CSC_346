#!/usr/bin/python3

print("Status: 200 OK")
print("Content-Type: text/plain")


print("Hello World")

