#! /usr/bin/python3

import threading
import sys
from socket import *
import random





def new_thread(conn_sock, dest_conn_sock):
    while True:
        try:
            n_sock = conn_sock.recv(1024)
        except:
            break
        if n_sock:
            try:
                dest_conn_sock.sendall(n_sock)
            except:
                break
        else:
            break
    try:
        conn_sock.close()
    except:
        return
    try:
        dest_conn_sock.close()
    except:
        return

def main():
    sock = socket()

    own_addr = ('0.0.0.0', random.randint(1024, 65535))
    sock.bind(own_addr)
    dest = sys.argv[1].split(':')
    dest_addr = dest[0]
    dest_port = int(dest[1])

    sock.listen(5)
    client, server = 0, 1
    
    while True:
        (conn_sock, conn_addr) = sock.accept()
        
        dest_sock = socket()
        destination_addr = (dest_addr, dest_port)
        dest_sock.connect(destination_addr)

        threading.Thread(target=new_thread, args=(conn_sock,dest_sock)).start()
        threading.Thread(target=new_thread, args=(dest_sock,conn_sock)).start()

        client, server = client+1, server+1

    sock.close()
    return

main()

